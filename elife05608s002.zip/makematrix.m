dim = size(data); % Get size of data variable
n = dim(1);         % Extract number of rows
offset = data(1,1) - 1;  % Get offset from zero
fitmatrix = zeros(63,63);  %  Allocate memory
for i = 1:n; fitmatrix(data(i,1)-offset, data(i,3)-offset) = data(i,2); end;

errormatrix = zeros(63,63);
for i = 1:n; errormatrix(data(i,7)-offset, data(i,9)-offset) = data(i,8); end;

figure(1);
clf; surf(fitmatrix); hold on; surf(errormatrix/10 + .01);