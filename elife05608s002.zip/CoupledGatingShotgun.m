%CoupledGatingShotGun.m
%Edward Cheng
%23 Feb 2011

clear all

%initialize variables
run=1;
fopened=1;

output_fname=input('Please enter the filename where output will be saved (including extension):','s');

fid=fopen(output_fname,'r+');

fname=input('Please enter file name (including extension):','s');
fprintf(fid,'%s \n',fname);

fprintf(fid,'%s \n',output_fname);
fprintf(fid,'%s ','File');
fprintf(fid,'%6s ','nPo');
fprintf(fid,'%6s ','Po');
fprintf(fid,'%8s ','kappa');
fprintf(fid,'%8s ','rho');
fprintf(fid,'%8s ','zeta');
fprintf(fid,'%8s ','Ca Moment');
fprintf(fid, '%8s ', 'mu');
fprintf(fid,'%9s ','precision');
fprintf(fid,'%9s \n','iteration');

Data1=importdata(fname);  %open file

[rows, cols]=size(Data1);

sample_time=0.2; %.2 ms


global quantal;

%%%GHK Calculation***

R=8.314; 
Temperature=298;
Faraday=9.649e4;
Voltage=input('Enter V (mV): ');
Voltage=Voltage*1e-3;
Vo=input('Enter Vo (mV): ');
Io=input('Enter Io (pA): ');
Vo=Vo*1e-3;
Ci=1e-7;
Co=2e-2;
z=2;

%Io=7.5;

%I=Io*V*(Ci-Co*exp(-z*F*V/(R*T)))*(1-exp(-z*F*Vo/(R*T)))/(Vo*(Ci-Co*exp(-z*F*Vo/(R*T)))*(1-exp(-z*F*V/(R*T))))
if Voltage==0
    ratio=(R*Temperature/(z*Faraday))*(Ci-Co)*(1-exp(-z*Faraday*Vo/(R*Temperature)))/(Vo*(Ci-Co*exp(-z*Faraday*Vo/(R*Temperature))))
elseif Vo==0
    ratio=((z*Faraday)/(R*Temperature))*Voltage*(Ci-Co*exp(-z*Faraday*Voltage/(R*Temperature)))/(1-exp(-z*Faraday*Voltage/(R*Temperature))*(Ci-Co))
else
    ratio=Voltage*(Ci-Co*exp(-z*Faraday*Voltage/(R*Temperature)))*(1-exp(-z*Faraday*Vo/(R*Temperature)))/(Vo*(Ci-Co*exp(-z*Faraday*Vo/(R*Temperature)))*(1-exp(-z*Faraday*Voltage/(R*Temperature))))
end

I=Io*ratio

%%%%%

quantal=I;


syms z r k;  %define zeta, rho, kappa as symbolic variables


V=[z 1-z;1-r r];

load /Documents/MATLAB/A_Two;
load /Documents/MATLAB/A_Three;
load /Documents/MATLAB/A_Four;
load /Documents/MATLAB/A_Five;
load /Documents/MATLAB/A_Six;
load /Documents/MATLAB/A_Seven;
load /Documents/MATLAB/A_Eight;


x=1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for x=1:cols/2
    close all; %close previous windows
    
    type=1; %input('Please enter 1 for sparklet, 2 for on cell current recording: ');

    x=2*x-1;
    
    
    time=transpose(Data1(:,x));    %vector of time
    ca_conc=transpose(Data1(:,x+1)); %vector of calcium concentration change
 
         
    
%     if type==1
%         %plot out our sparklet recording
%         
%         subplot(2,1,1);
%         plot(time,ca_conc,'r');
%         xlabel('time (ms)');
%         ylabel('\DeltaCa2+ conc (nM)');
%         title(['Sparklet Recording from ',fname]);
%         subplot(2,1,2);
%         plot(f,2*abs(FTca_conc(1:NFFT/2+1)),'r');
%         xlabel('frequency (Hz)');
%         ylabel('FTca_conc');
%         title('Frequency Spectrum of Sparklet Recording Data1');
%         
%     else
%         subplot(3,1,1);
%         plot(time,ca_conc,'r');
%         xlabel('time (ms)');
%         ylabel('ICa (pA)');
%         title(['Current Recording from ',fname]);
%         pAperbin=1;
%         
%         replot=1;
%         
%         while replot==1
%             subplot(3,1,2);
%             binMax=ceil(max(ca_conc));
%             binMin=floor(min(ca_conc));
%             bins=(binMax-binMin)/pAperbin;
%             bar(linspace(binMin,binMax,bins),hist(ca_conc,bins));
%             xlabel('ICa (pA)');
%             ylabel('Counts');
%             title(['All-point histogram from ',fname]);
%             subplot(3,1,3); %positive frequency domain representation of our data,
%             plot(f,2*abs(FTca_conc(1:NFFT/2+1)),'r');
%             xlabel('frequency (Hz)');
%             ylabel('FTICa');
%             title('Frequency Spectrum of Sparklet Recording Data1');
%             replot=input('Please enter 1 if you want to replot with different width (pA) per bin in histogram (default is 1 pA): ');
%             if replot==1
%                 pAperbin=input('Please enter pA per bin in histogram: ');
%             end
%         end
%         
%     end
    
  
    
   
    
   
   

    
    states=zeros(1,length(time)); %initiate states vector
    closedtime=0;
    opentime1=0;
    opentime2=0;
    opentime3=0;
    opentime4=0;
    opentime5=0;
    opentime6=0;
    opentime7=0;
    opentime8=0;
    
    CurrentState=0;
    PrevState=10000;
    
    %initialize variable for open time with
    %1,2,....3 channels open
    opentime=0; %initialize variable for total open time
    closedtime=0; %initialize variable for total closed time
    
    ca_conc0=0; %initialize a variable to store all data associated w/closed state to calculate std dev
    ca_conc1=0; %initialize variable to store all data associated w/1 channel open
    ca_conc2=0; %ditto for 2 channels
    ca_conc3=0; %ditto for 3
    ca_conc4=0; %ditto for 4
    ca_conc5=0;
    ca_conc6=0;
    ca_conc7=0;
    ca_conc8=0;
    
    
    
    %50% threshold analysis to assign states to each timepoint.
    %50% threshold analysis to assign states to each timepoint.
    for i=1:length(time)
        if ca_conc(i)<(quantal/2)
            states(i)=0; %state is closed (0 channel open)
            closedtime=closedtime+1;  %update closedtime length
            ca_conc0(closedtime)=ca_conc(i); %store data to closed state data vector
        elseif ca_conc(i)>=(quantal/2) && ca_conc(i)<(3*quantal/2)
            if i<3
                if median(ca_conc(i):ca_conc(i+4))>=(quantal/2)
                    states(i)=1;
                    opentime1=opentime1+1;
                    opentime=opentime+1;
                    ca_conc1(opentime1)=ca_conc(i);
                else
                    states(i)=0; %state is closed (0 channel open)
                    closedtime=closedtime+1;  %update closedtime length
                    ca_conc0(closedtime)=ca_conc(i); %store data to closed state data vector
                end
            elseif i>(length(time)-3)
                if median(ca_conc(i-4):ca_conc(i))>=(quantal/2)
                    states(i)=1;
                    opentime1=opentime1+1;
                    opentime=opentime+1;
                    ca_conc1(opentime1)=ca_conc(i);
                else
                    states(i)=0; %state is closed (0 channel open)
                    closedtime=closedtime+1;  %update closedtime length
                    ca_conc0(closedtime)=ca_conc(i); %store data to closed state data vector
                end
            else
                if median(ca_conc(i-2):ca_conc(i+2))>=(quantal/2)
                    states(i)=1;
                    opentime1=opentime1+1;
                    opentime=opentime+1;
                    ca_conc1(opentime1)=ca_conc(i);
                else
                    states(i)=0; %state is closed (0 channel open)
                    closedtime=closedtime+1;  %update closedtime length
                    ca_conc0(closedtime)=ca_conc(i); %store data to closed state data vector
                end
            end
        elseif ca_conc(i)>=(3*quantal/2) && ca_conc(i)<(5*quantal/2)
            states(i)=2;
            opentime2=opentime2+1;
            opentime=opentime+2; %2 channels are open at once
            ca_conc2(opentime2)=ca_conc(i);
        elseif ca_conc(i)>=(5*quantal/2) && ca_conc(i)<(7*quantal/2)
            states(i)=3;
            opentime3=opentime3+1;
            opentime=opentime+3; %3 channels are open at once
            ca_conc3(opentime3)=ca_conc(i);
        elseif ca_conc(i)>=(7*quantal/2) && ca_conc(i)<(9*quantal/2)
            states(i)=4;
            opentime4=opentime4+1;
            opentime=opentime+4; %4 channels are open at once
            ca_conc4(opentime4)=ca_conc(i);
        elseif ca_conc(i)>=(9*quantal/2) && ca_conc(i)<(11*quantal/2)
            states(i)=5;
            opentime5=opentime5+1;
            opentime=opentime+5;
            ca_conc5(opentime5)=ca_conc(i);
        elseif ca_conc(i)>=(11*quantal/2) && ca_conc(i)<(13*quantal/2)
            states(i)=6;
            opentime6=opentime6+1;
            opentime=opentime+6;
            ca_conc6(opentime6)=ca_conc(i);
        elseif ca_conc(i)>=(13*quantal/2) && ca_conc(i)<(15*quantal/2)
            states(i)=7;
            opentime7=opentime7+1;
            opentime=opentime+7;
            ca_conc7(opentime7)=ca_conc(i);
        elseif ca_conc(i)>=(15*quantal/2) && ca_conc(i)<(17*quantal/2)
            states(i)=8;
            opentime8=opentime8+1;
            opentime=opentime+8;
            ca_conc8(opentime8)=ca_conc(i);
        end
    end
    
  
    
    std_dev0=std(ca_conc0); %calculate std dev of data assoc w/each quantal level
    std_dev1=std(ca_conc1);
    std_dev2=std(ca_conc2);
    std_dev3=std(ca_conc3);
    std_dev4=std(ca_conc4);
    std_dev5=std(ca_conc5);
    std_dev6=std(ca_conc6);
    std_dev7=std(ca_conc7);
    std_dev8=std(ca_conc8);
    
    bin_ca_conc=zeros(1,length(time)); %initialize vector to store our binned ca_conc data
    
    %%
    %Since the Baum-Welch HMM algorithm in Matlab used to estimate the transition matrix requires
    %the "sequence" of observables to be integers, let's bin our data, with bin size based on
    %the distribution (std dev) of the raw calcium change data.  An integer number,
    %rank based on the calcium change level, is assigned to each bin, which
    %gives us the sequence of integer states needed to run the function
    %hmmestimate
    bin_ca_conc=bin_seq(ca_conc,states,std_dev0,std_dev1,std_dev2,std_dev3,...
        std_dev4,std_dev5,std_dev6,std_dev7,std_dev8);
    
%     figure;
%     
%     subplot(3,1,1);
%     plot(time,states,'r');
%     ylabel('# Open Channels');
%     title(['Open Channels by 50% Threshold, nPs=',num2str(nPs),' Ps=',num2str(Ps),' from ',fname]);
%     
%     subplot(3,1,2);
%     plot(time,bin_ca_conc,'r');
%     title('Binned \DeltaCa Concentration Data as a Sequence of Markovian Nodes');
%     ylabel('Bin Number');
%     
%     subplot(3,1,3);
%     hold on;
%     plot(time,ca_conc,'b');%also plot out std dev associated with each level
%     plot(time,(quantal+std_dev1)*ones(1,length(time)),'g');
%     plot(time,(quantal-std_dev1)*ones(1,length(time)),'g');
%     plot(time,(2*quantal-std_dev2)*ones(1,length(time)),'c');
%     plot(time,(2*quantal+std_dev2)*ones(1,length(time)),'c');
%     plot(time,(3*quantal+std_dev3)*ones(1,length(time)),'m');
%     plot(time,(3*quantal-std_dev3)*ones(1,length(time)),'m');
%     plot(time,(4*quantal+std_dev4)*ones(1,length(time)),'r');
%     plot(time,(4*quantal-std_dev4)*ones(1,length(time)),'r');
%     title('\Delta Ca2+ Conc, with Calculated Std Dev of each quantal level');
%     xlabel('Time (s)');
%     ylabel('\DeltaCa2+ Conc (nM)');
%     
    
    
    %%
    %Since the Baum-Welch HMM algorithm in Matlab used to estimate the transition matrix requires
    %the "sequence" of observables to be integers, let's bin our data, with bin size based on
    %the distribution (std dev) of the raw calcium change data.  An integer number,
    %rank based on the calcium change level, is assigned to each bin, which
    %gives us the sequence of integer states needed to run the function
    %hmmestimate
    bin_ca_conc=bin_seq(ca_conc,states,std_dev0,std_dev1,std_dev2,std_dev3,...
        std_dev4,std_dev5,std_dev6,std_dev7,std_dev8);
    
%     figure;
%     
%     subplot(3,1,1);
%     plot(time,states,'r');
%     ylabel('# Open Channels');
%     title(['Open Channels by 50% Threshold, nPs=',num2str(nPs),' Ps=',num2str(Ps),' from ',fname]);
%     
%     subplot(3,1,2);
%     plot(time,bin_ca_conc,'r');
%     if type==1
%         title('Binned \DeltaCa Concentration Data as a Sequence of Markovian Nodes');
%         ylabel('Bin Number');
%     else
%         title('Binned ICa Data as a Sequence of Markovian Nodes');
%         ylabel('Bin Number');
%     end
%     
%     subplot(3,1,3);
%     hold on;
%     plot(time,ca_conc,'b');%also plot out std dev associated with each level
%     plot(time,(quantal+std_dev1)*ones(1,length(time)),'g');
%     plot(time,(quantal-std_dev1)*ones(1,length(time)),'g');
%     plot(time,(2*quantal-std_dev2)*ones(1,length(time)),'c');
%     plot(time,(2*quantal+std_dev2)*ones(1,length(time)),'c');
%     plot(time,(3*quantal+std_dev3)*ones(1,length(time)),'m');
%     plot(time,(3*quantal-std_dev3)*ones(1,length(time)),'m');
%     plot(time,(4*quantal+std_dev4)*ones(1,length(time)),'r');
%     plot(time,(4*quantal-std_dev4)*ones(1,length(time)),'r');
%     if type==1
%         title('\Delta Ca2+ Conc, with Calculated Std Dev of each quantal level');
%         xlabel('Time (s)');
%         ylabel('\DeltaCa2+ Conc (nM)');
%     else
%         title('ICa, with Calculated Std Dev of each quantal level');
%         xlabel('Time (s)');
%         ylabel('ICa (pA)');
%     end
%     
%     
    
    
    states=states+1;
    
    %Calculate estimated Transition and emision matrices
    [TransitionEst, EmissionEst]=hmmestimate(bin_ca_conc,states); %uses Baum-Welch
    %algorithm to estimate transition and emissionmatrices based on our binned
    %Ca2+ concentration change data, which are the observable sequences used
    %for HMM estimate.
    
    A_hat=TransitionEst;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    L=size(A_hat,1)-1; % %max # of channels
    
    nPs=opentime/(opentime+closedtime); %calculate the multiple open probability nPs
    Ps=(opentime1+opentime2+opentime3+opentime4)/(L*length(time)); %calculate open probability Ps
    
    
    fopened=1;
    
    F=0;
    if L==2
        for i=1:L
            for j=1:L
                F=F+(A_Two(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==3
        for i=1:L
            for j=1:L
                F=F+(A_Three(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==4
        for i=1:L
            for j=1:L
                F=F+(A_Four(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==5
        for i=1:L
            for j=1:L
                F=F+(A_Five(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==6
        for i=1:L
            for j=1:L
                F=F+(A_Six(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==7
        for i=1:L
            for j=1:L
                F=F+(A_Seven(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==8
        for i=1:L
            for j=1:L
                F=F+(A_Eight(i,j)-A_hat(i,j))^2;
            end
        end
    elseif L==1
        disp('Error-Only 1 channel open!');
        fprintf(fid,'%s ',fname);
        fprintf(fid,'%6.2f ',nPs);
        fprintf(fid,'%6.2f ',Ps);
        fprintf(fid,'%8s ','0');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%9s ','N/A');
        fprintf(fid,'%5s \n','N/A');        
%         run=input('Analyze more data? (enter 0 to quit)- ');
        continue; %return to the beginning of while(run) loop
    elseif L==0
   
        disp('Error-Only 1 channel open!');
        fprintf(fid,'%s ',fname);
        fprintf(fid,'%6.2f ',nPs);
        fprintf(fid,'%6.2f ',Ps);
        fprintf(fid,'%8s ','0');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%8s ','N/A');
        fprintf(fid,'%9s ','N/A');
        fprintf(fid,'%5s \n','N/A');        
%         run=input('Analyze more data? (enter 0 to quit)- ');
        continue; %return to the beginning of while(run) loop
    end
    
    
    F=0.5*F;
    
    Ftheta=matlabFunction(F);
    
    %initial guess for [kappa,rho,zeta]
    theta_o=[0.5 0.5 0.5];
    
    %caculate the symbolic expression for the gradient
    dFdtheta=[diff(F,k) diff(F,r) diff(F,z)];
    
    %define the gradient expression as a function
    dFdt=matlabFunction(dFdtheta);
    
    %initialize parameters gradient descent
    thetaold=theta_o;
    thetanew=[0 0 0];
    precision=0.000005;
    %scaling factor for the gradient
    mu=0.001;
    
    loop=1;
    iteration=1;
    while( (norm(thetaold-thetanew)/norm(thetaold))>precision)
        thetaold=thetanew;
        thetanew=thetaold-mu*dFdt(thetaold(1,1),thetaold(1,2),thetaold(1,3));
        iteration=iteration+1;
        if iteration >=20000
            loop=loop+1
            precision=precision*10;
            iteration=1;
        end
  
        if loop==4
            break
        end
 
 
    end
    
    %display(iteration);
    
    %re-caculate if any element of theta is outside [0,1]
    loop=1;  %initialize variable to prevent infinite loops
    %try to get kappa, rho, zeta within [0,1]
    while( thetanew(1,1)<0 || thetanew (1,1)>1 || thetanew(1,2)<0 || ...
            thetanew(1,2)>1 || thetanew(1,3)<0 || thetanew(1,3)>1)
        precision=precision*1.0001; %relax precision for every loop
        mu=mu/1.01; %decrease gradient scaling factor for every loop
        thetaold=theta_o; %re-initialize variables
        thetanew=[0 0 0]; %ditto
        iteration=1; %ditto
        loop=loop+1; %increment loop
        while( (norm(thetaold-thetanew)/norm(thetaold))>precision)
            thetaold=thetanew;
            thetanew=thetaold-mu*dFdt(thetaold(1,1),thetaold(1,2),thetaold(1,3));
            iteration=iteration+1;
            if iteration==1000
                break
            end
        end
        %only allow max 700 loops
        if loop==750
            break
        end
    end
    
    thetanew
    
    output.file_name=fname;
    output.nPs=nPs;
    output.Ps=Ps;
    output.k=thetanew(1,1);
    output.r=thetanew(1,2);
    output.z=thetanew(1,3);
    output.moment=thetanew(1,1)*thetanew(1,2)/thetanew(1,3);
    output.mu=mu;
    output.precision=precision;
    output.iteration=iteration;
    
    fprintf(fid,'%s ',output.file_name);
    fprintf(fid,'%6.2f ',output.nPs);
    fprintf(fid,'%6.2f ',output.Ps);
    fprintf(fid,'%8.4f ',output.k);
    fprintf(fid,'%8.4f ',output.r);
    fprintf(fid,'%8.4f ',output.z);
    fprintf(fid,'%8.4f ',output.moment);
    fprintf(fid,'%8.6f ',output.mu);
    fprintf(fid,'%9.6f ',output.precision);
    fprintf(fid,'%5.1f \n',output.iteration);
    
    fopened=fopened+1;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%SIMULATION
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%BLOCK%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       simulate=input('Do you want to simulate a trace using the fitted parameters? (1=yes) ');
%     
%     if simulate==1
%         kappa=input('Please enter kappa='); %thetanew(1,1);
%         rho=input('Please enter rho='); %thetanew(1,2);
%         zeta=input('Please enter zeta='); %thetanew(1,3);
%         if L==2
%             TrMat=double(subs(A_Two,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         elseif L==3
%             TrMat=double(subs(A_Three,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         elseif L==4
%             TrMat=double(subs(A_Four,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         elseif L==5
%             TrMat=double(subs(A_Five,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         elseif L==6
%             TrMat=double(subs(A_Six,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         elseif L==7
%             TrMat=double(subs(A_Seven,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         elseif L==8
%             TrMat=double(subs(A_Eight,{k,r,z},{kappa,rho,zeta}));
%             [SimSeq, SimStates]=hmmgenerate(length(time),TrMat,EmissionEst);
%         end
%         
%         SimConc=Seq2Conc(SimSeq, std_dev0, std_dev1, std_dev2, std_dev3,...
%             std_dev4, std_dev5, std_dev6, std_dev7, std_dev8);
%         [SimStates, SimnPs, SimPs, SimCa_conc0, SimCa_conc1, SimCa_conc2, SimCa_conc3, SimCa_conc4, SimCa_conc5, SimCa_conc6, SimCa_conc7, SimCa_conc8]=threshold(time, SimConc);
%         figure;
%         subplot(2,1,1);
%         plot(time,SimConc,'r');
%         ylabel('\DeltaCa2+ Concentration (nM)');
%         title('Simulated Trace'); %, Ps=',num2str(Ps),' Extracted from ',fname, '\nThis simulation: nPs=',num2str(SimnPs),' Ps=',num2str(SimPs)]);
%         subplot(2,1,2);
%         plot(time,SimStates-1,'r');
%         ylabel('Open Channels');
%         xlabel('Time (s)');
%         
%         
%     end
    %%%%%%%%%%%%%%%%%%%%%%%%END SIMULATION
    %%%%%%%%%%%%%%%%%%%%%%%%BLOCK%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     run=input('Analyze more data? (enter 0 to quit)- ');
    
end

fclose(fid);






                
             
                    






                
             
                    