function [ seq ] = bin_seq( ca_conc,states,std_dev0,std_dev1,std_dev2,std_dev3,std_dev4,std_dev5,std_dev6,std_dev7,std_dev8) 
%by EC
%Since the Baum-Welch HMM algorithm in Matlab used to estimate the transition matrix requires
%the "sequence" of observables to be integers, let's bin our data, with bin size based on
%the distribution (std dev) of the raw calcium change data around each quantal level.  
%An integer number rank based on the calcium change level, is assigned to each bin, which
%gives us the sequence of integer states needed to run the function
%hmmestimate

bin_ca_conc=zeros(1,length(states));
global quantal 

for i=1:length(states)
    if states(i)==0
        if ca_conc(i)<(std_dev0/2) && ca_conc(i)>(-std_dev0/2)
            bin_ca_conc(i)=4; %assign bin #, from lowest level up
        elseif ca_conc(i)>=(std_dev0/2) && ca_conc(i)<(3*std_dev0/2)
            bin_ca_conc(i)=5;  %         midpoint=std_dev0;
        elseif ca_conc(i)<=(-std_dev0/2) && ca_conc(i)>(-3*std_dev0/2)
            bin_ca_conc(i)=3;  %        midpoint=-std_dev0;
        elseif ca_conc(i)>=(3*std_dev0/2) && ca_conc(i)<(5*std_dev0/2)
            bin_ca_conc(i)=6;  %        midpoint=2*std_dev0;
        elseif ca_conc(i)<=(-3*std_dev0/2) && ca_conc(i)>(-5*std_dev0/2)
            bin_ca_conc(i)=2;%          midpoint=-2*std_dev0;
        elseif ca_conc(i)>=(5*std_dev0/2) && ca_conc(i)<(quantal/2)
            bin_ca_conc(i)=7;%          midpoint=(quantal/2-5*std_dev0/2)/2;
        else
            bin_ca_conc(i)=1;%this is the lowest signal level, ergo it's level 1 midpoint=-(quantal/2-5*std_dev0/2)/2;
        end
    elseif states(i)==1
        if ca_conc(i)<(quantal+std_dev1/2) && ca_conc(i)>(quantal-std_dev1/2)
            bin_ca_conc(i)=10;%         midpoint=quantal;
        elseif ca_conc(i)>=(quantal+std_dev1/2) && ca_conc(i)<(quantal+3*std_dev1/2)
            bin_ca_conc(i)=11;%         midpoint=quantal+std_dev1;
        elseif ca_conc(i)<=(quantal-std_dev1/2) && ca_conc(i)>(quantal-3*std_dev1/2)
            bin_ca_conc(i)=9;%          midpoint=quantal-std_dev1;
        elseif ca_conc(i)>=(quantal+3*std_dev1/2) && ca_conc(i)<(3*quantal/2)
            bin_ca_conc(i)=12; %        midpoint=quantal+(quantal/2-3*std_dev1/2)/2;
        else
            bin_ca_conc(i)=8;%         midpoint=quantal+(-quantal/2-3*std_dev1/2)/2;
        end
    elseif states(i)==2
        if ca_conc(i)<(2*quantal+std_dev2/2) && ca_conc(i)>(2*quantal-std_dev2/2)
            bin_ca_conc(i)=15;%         midpoint=2*quantal;
        elseif ca_conc(i)>=(2*quantal+std_dev2/2) && ca_conc(i)<(2*quantal+3*std_dev2/2)
            bin_ca_conc(i)=16;%         midpoint=2*quantal+std_dev2;
        elseif ca_conc(i)<=(2*quantal-std_dev2/2) && ca_conc(i)>(2*quantal-3*std_dev2/2)
            bin_ca_conc(i)=14;%         midpoint=2*quantal-std_dev2;
        elseif ca_conc(i)>=(2*quantal+3*std_dev2/2) && ca_conc(i)<(5*quantal/2)
            bin_ca_conc(i)=17;%         midpoint=2*quantal+(3*quantal/2-3*std_dev2/2)/2; 
        else
            bin_ca_conc(i)=13;%         midpoint=2*quantal+(-3*quantal/2-3*std_dev2/2)/2;
        end
    elseif states(i)==3
        if ca_conc(i)<(3*quantal+std_dev3/2) && ca_conc(i)>(3*quantal-std_dev3/2)
            bin_ca_conc(i)=20;%         midpoint=3*quantal;
        elseif ca_conc(i)>=(3*quantal+std_dev3/2) && ca_conc(i)<(3*quantal+3*std_dev3/2)
            bin_ca_conc(i)=21;%         midpoint=3*quantal+std_dev3;
        elseif ca_conc(i)<=(3*quantal-std_dev3/2) && ca_conc(i)>(3*quantal-3*std_dev3/2)
            bin_ca_conc(i)=19;%         midpoint=3*quantal-std_dev3;
        elseif ca_conc(i)>=(3*quantal+3*std_dev3/2) && ca_conc(i)<(7*quantal/2)
            bin_ca_conc(i)=22;%         midpoint=3*quantal+(5*quantal/2-3*std_dev3/2)/2; 
        else
            bin_ca_conc(i)=18;%         bmidpoint=3*quantal+(-5*quantal/2-3*std_dev3/2)/2;
        end
    elseif states(i)==4
        if ca_conc(i)<(4*quantal+std_dev4/2) && ca_conc(i)>(4*quantal-std_dev4/2)
            bin_ca_conc(i)=25;%         midpoint=4*quantal;
        elseif ca_conc(i)>=(4*quantal+std_dev4/2) && ca_conc(i)<(4*quantal+3*std_dev4/2)
            bin_ca_conc(i)=26;%         midpoint=4*quantal+std_dev4;
        elseif ca_conc(i)<=(4*quantal-std_dev4/2) && ca_conc(i)>(4*quantal-3*std_dev4/2)
            bin_ca_conc(i)=24;%         midpoint=4*quantal-std_dev4;
        elseif ca_conc(i)>=(4*quantal+3*std_dev4/2) && ca_conc(i)<(9*quantal/2)
            bin_ca_conc(i)=27;%         midpoint=4*quantal+(7*quantal/2-3*std_dev4/2)/2; 
        else
            bin_ca_conc(i)=23;%        midpoint=4*quantal+(-7*quantal/2-3*std_dev4/2)/2;
        end
    elseif states(i)==5
         if ca_conc(i)<(4*quantal+std_dev5/2) && ca_conc(i)>(4*quantal-std_dev5/2)
            bin_ca_conc(i)=30;%         midpoint=5*quantal;
        elseif ca_conc(i)>=(4*quantal+std_dev5/2) && ca_conc(i)<(4*quantal+3*std_dev5/2)
            bin_ca_conc(i)=31;%         midpoint=5*quantal+std_dev5;
        elseif ca_conc(i)<=(4*quantal-std_dev5/2) && ca_conc(i)>(4*quantal-3*std_dev5/2)
            bin_ca_conc(i)=29;%         midpoint=5*quantal-std_dev5;
        elseif ca_conc(i)>=(4*quantal+3*std_dev5/2) && ca_conc(i)<(11*quantal/2)
            bin_ca_conc(i)=32;%         midpoint=5*quantal+(9*quantal/2-3*std_dev5/2)/2; 
        else
            bin_ca_conc(i)=28;%        midpoint=5*quantal+(-9*quantal/2-3*std_dev5/2)/2;
         end
    elseif states(i)==6
         if ca_conc(i)<(4*quantal+std_dev6/2) && ca_conc(i)>(4*quantal-std_dev6/2)
            bin_ca_conc(i)=35;%         midpoint=6*quantal;
        elseif ca_conc(i)>=(4*quantal+std_dev6/2) && ca_conc(i)<(4*quantal+3*std_dev6/2)
            bin_ca_conc(i)=36;%         midpoint=6*quantal+std_dev6;
        elseif ca_conc(i)<=(4*quantal-std_dev6/2) && ca_conc(i)>(4*quantal-3*std_dev6/2)
            bin_ca_conc(i)=34;%         midpoint=6*quantal-std_dev6;
        elseif ca_conc(i)>=(4*quantal+3*std_dev6/2) && ca_conc(i)<(13*quantal/2)
            bin_ca_conc(i)=37;%         midpoint=6*quantal+(11*quantal/2-3*std_dev6/2)/2; 
        else
            bin_ca_conc(i)=33;%        midpoint=6*quantal+(-11*quantal/2-3*std_dev6/2)/2;
         end
    elseif states(i)==7
        if ca_conc(i)<(4*quantal+std_dev7/2) && ca_conc(i)>(4*quantal-std_dev7/2)
            bin_ca_conc(i)=36;%         midpoint=7*quantal;
        elseif ca_conc(i)>=(4*quantal+std_dev7/2) && ca_conc(i)<(4*quantal+3*std_dev7/2)
            bin_ca_conc(i)=37;%         midpoint=7*quantal+std_dev7;
        elseif ca_conc(i)<=(4*quantal-std_dev7/2) && ca_conc(i)>(4*quantal-3*std_dev7/2)
            bin_ca_conc(i)=35;%         midpoint=7*quantal-std_dev7;
        elseif ca_conc(i)>=(4*quantal+3*std_dev7/2) && ca_conc(i)<(15*quantal/2)
            bin_ca_conc(i)=38;%         midpoint=7*quantal+(13*quantal/2-3*std_dev7/2)/2; 
        else
            bin_ca_conc(i)=34;%        midpoint=7*quantal+(-13*quantal/2-3*std_dev7/2)/2;
        end
    elseif states(i)==8
         if ca_conc(i)<(4*quantal+std_dev8/2) && ca_conc(i)>(4*quantal-std_dev8/2)
            bin_ca_conc(i)=41;%         midpoint=8*quantal;
        elseif ca_conc(i)>=(4*quantal+std_dev8/2) && ca_conc(i)<(4*quantal+3*std_dev8/2)
            bin_ca_conc(i)=42;%         midpoint=8*quantal+std_dev8;
        elseif ca_conc(i)<=(4*quantal-std_dev8/2) && ca_conc(i)>(4*quantal-3*std_dev8/2)
            bin_ca_conc(i)=40;%         midpoint=8*quantal-std_dev8;
        elseif ca_conc(i)>=(4*quantal+3*std_dev8/2) 
            bin_ca_conc(i)=43;%         midpoint=8*quantal+(15*quantal/2-3*std_dev8/2)/2; 
        else
            bin_ca_conc(i)=39;%        midpoint=8*quantal+(-15*quantal/2-3*std_dev8/2)/2;
        end
    end
end

seq=bin_ca_conc;

end

