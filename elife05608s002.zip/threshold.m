function [States, nPs, Ps, Ca_conc0, Ca_conc1, Ca_conc2, Ca_conc3, Ca_conc4, Ca_conc5, Ca_conc6, Ca_conc7, Ca_conc8]=threshold(time, ca_conc)

 
global quantal;

    states=zeros(1,length(time)); %initiate states vector
    closedtime=0;
    opentime1=0;
    opentime2=0;
    opentime3=0;
    opentime4=0;
    opentime5=0;
    opentime6=0;
    opentime7=0;
    opentime8=0;
    
    %initialize variable for open time with
    %1,2,....3 channels open
    opentime=0; %initialize variable for total open time
    closedtime=0; %initialize variable for total closed time
    
    ca_conc0=0; %initialize a variable to store all data associated w/closed state to calculate std dev
    ca_conc1=0; %initialize variable to store all data associated w/1 channel open
    ca_conc2=0; %ditto for 2 channels
    ca_conc3=0; %ditto for 3
    ca_conc4=0; %ditto for 4
    ca_conc5=0;
    ca_conc6=0;
    ca_conc7=0;
    ca_conc8=0;
    
    
    
    %50% threshold analysis to assign states to each timepoint.
    for i=1:length(time)
        if ca_conc(i)<(quantal/2)
            states(i)=0; %state is closed (0 channel open)
            closedtime=closedtime+1;  %update closedtime length
            ca_conc0(closedtime)=ca_conc(i); %store data to closed state data vector
        elseif ca_conc(i)>=(quantal/2) && ca_conc(i)<(3*quantal/2)
            states(i)=1;
            opentime1=opentime1+1;
            opentime=opentime+1;
            ca_conc1(opentime1)=ca_conc(i);
        elseif ca_conc(i)>=(3*quantal/2) && ca_conc(i)<(5*quantal/2)
            states(i)=2;
            opentime2=opentime2+1;
            opentime=opentime+2; %2 channels are open at once
            ca_conc2(opentime2)=ca_conc(i);
        elseif ca_conc(i)>=(5*quantal/2) && ca_conc(i)<(7*quantal/2)
            states(i)=3;
            opentime3=opentime3+1;
            opentime=opentime+3; %3 channels are open at once
            ca_conc3(opentime3)=ca_conc(i);
        elseif ca_conc(i)>=(7*quantal/2) && ca_conc(i)<(9*quantal/2)
            states(i)=4;
            opentime4=opentime4+1;
            opentime=opentime+4; %4 channels are open at once
            ca_conc4(opentime4)=ca_conc(i);
        elseif ca_conc(i)>=(9*quantal/2) && ca_conc(i)<(11*quantal/2)
            states(i)=5;
            opentime5=opentime5+1;
            opentime=opentime+5;
            ca_conc5(opentime5)=ca_conc(i);
        elseif ca_conc(i)>=(11*quantal/2) && ca_conc(i)<(13*quantal/2)
            states(i)=6;
            opentime6=opentime6+1;
            opentime=opentime6+6;
            ca_conc6(opentime6)=ca_conc(i);
        elseif ca_conc(i)>=(13*quantal/2) && ca_conc(i)<(15*quantal/2)
            states(i)=7;
            opentime7=opentime7+1;
            opentime=opentime+7;
            ca_conc7(opentime7)=ca_conc(i);
        elseif ca_conc(i)>=(15*quantal/2) && ca_conc(i)<(17*quantal/2)
            states(i)=8;
            opentime8=opentime8+1;
            opentime=opentime+8;
            ca_conc8(opentime8)=ca_conc(i);
        end
    end
    
    %outputs
    States=states;
    nPs=opentime/length(time); %calculate the multiple open probability nPs
    Ps=(opentime1+opentime2+opentime3+opentime4)/length(time); %calculate open probability Ps
    Ca_conc0=ca_conc0;
    Ca_conc1=ca_conc1;
    Ca_conc2=ca_conc2;
    Ca_conc3=ca_conc3;
    Ca_conc4=ca_conc4;
    Ca_conc5=ca_conc5;
    Ca_conc6=ca_conc6;
    Ca_conc7=ca_conc7;
    Ca_conc8=ca_conc8;
end    