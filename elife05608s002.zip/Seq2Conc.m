function [ Conc ] = Seq2Conc(SimSeq, std_dev0, std_dev1, std_dev2, std_dev3, std_dev4, std_dev5, std_dev6, std_dev7, std_dev8)
%by EC
%Seq2Conc a function that converts markovian 
%nodes back into concentration change, by taking the concentration corresponding
%to themidpoint of every bin

SimConc=zeros(1,length(SimSeq));
global quantal

for i=1:length(SimSeq)
    if SimSeq(i)==1
        SimConc(i)=-(quantal/2-5*std_dev0/2)/2;
    elseif SimSeq(i)==2
        SimConc(i)=-2*std_dev0;
    elseif SimSeq(i)==3
        SimConc(i)=-std_dev0;
    elseif SimSeq(i)==4
        SimConc(i)=0;
    elseif SimSeq(i)==5
        SimConc(i)=std_dev0;
    elseif SimSeq(i)==6
        SimConc(i)=2*std_dev0;
    elseif SimSeq(i)==7
        SimConc(i)=(quantal/2-5*std_dev0/2)/2;
    elseif SimSeq(i)==8
        SimConc(i)=quantal+(-quantal/2-3*std_dev1/2)/2;
    elseif SimSeq(i)==9
        SimConc(i)=quantal-std_dev1;
    elseif SimSeq(i)==10
        SimConc(i)=quantal;
    elseif SimSeq(i)==11
        SimConc(i)=quantal+std_dev1;
    elseif SimSeq(i)==12
        SimConc(i)=quantal+(quantal/2-3*std_dev1/2)/2;
    elseif SimSeq(i)==13
        SimConc(i)=2*quantal+(-3*quantal/2-3*std_dev2/2)/2;
    elseif SimSeq(i)==14
        SimConc(i)=2*quantal-std_dev2;
    elseif SimSeq(i)==15
        SimConc(i)=2*quantal;
    elseif SimSeq(i)==16
        SimConc(i)=2*quantal+std_dev2;
    elseif SimSeq(i)==17
        SimConc(i)=2*quantal+(3*quantal/2-3*std_dev2/2)/2;
    elseif SimSeq(i)==18
        SimConc(i)=3*quantal+(-5*quantal/2-3*std_dev3/2)/2;
    elseif SimSeq(i)==19
        SimConc(i)=3*quantal-std_dev3;
    elseif SimSeq(i)==20
        SimConc(i)=3*quantal;
    elseif SimSeq(i)==21
        SimConc(i)=3*quantal+std_dev3;
    elseif SimSeq(i)==22
        SimConc(i)=3*quantal+(5*quantal/2-3*std_dev3/2)/2;
    elseif SimSeq(i)==23
        SimConc(i)=4*quantal+(-7*quantal/2-3*std_dev4/2)/2;
    elseif SimSeq(i)==24
        SimConc(i)=4*quantal-std_dev4;
    elseif SimSeq(i)==25
        SimConc(i)=4*quantal;
    elseif SimSeq(i)==26
        SimConc(i)=4*quantal+std_dev4;
    elseif SimSeq(i)==27
        SimConc(i)=4*quantal+(7*quantal/2-3*std_dev4/2)/2;
    elseif SimSeq(i)==28
        SimConc(i)=5*quantal+(-9*quantal/2-3*std_dev5/2)/2;
    elseif SimSeq(i)==29
        SimConc(i)=5*quantal-std_dev5;
    elseif SimSeq(i)==30
        SimConc(i)=5*quantal;
    elseif SimSeq(i)==31
        SimConc(i)=5*quantal+std_dev5;
    elseif SimSeq(i)==32
        SimConc(i)=5*quantal+(9*quantal/2-3*std_dev5/2)/2;
    elseif SimSeq(i)==33
        SimConc(i)=6*quantal+(-11*quantal/2-3*std_dev6/2)/2;
    elseif SimSeq(i)==34
        SimConc(i)=6*quantal-std_dev6;
    elseif SimSeq(i)==35
        SimConc(i)=6*quantal;
    elseif SimSeq(i)==36
        SimConc(i)=6*quantal+std_dev6;
    elseif SimSeq(i)==37
        SimConc(i)=6*quantal+(11*quantal/2-3*std_dev6/2)/2;
    elseif SimSeq(i)==38
        SimConc(i)=7*quantal+(13*quantal/2-3*std_dev7/2)/2;
    elseif SimSeq(i)==39
        SimConc(i)=8*quantal+(-15*quantal/2-3*std_dev8/2)/2;
    elseif SimSeq(i)==40
        SimConc(i)=8*quantal-std_dev8;
    elseif SimSeq(i)==41
        SimConc(i)=8*quantal;
    elseif SimSeq(i)==42
        SimConc(i)=8*quantal+std_dev8;
    elseif SimSeq(i)==43
        SimConc(i)=8*quantal+(15*quantal/2-3*std_dev8/2)/2;
    end
end

Conc=SimConc;

end

